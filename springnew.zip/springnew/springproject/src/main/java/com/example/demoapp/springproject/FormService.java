package com.example.demoapp.springproject;

import java.util.ArrayList;
import java.util.Arrays;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.mongodb.Mongo;
import com.mongodb.MongoClient;

import org.springframework.stereotype.Service;

@Service
public class FormService {
	ArrayList<String> behavioral; 
	ArrayList<String> overall;
	
	public FormService() {
		this.behavioral = new ArrayList<>(Arrays.asList("Communicates effectively with supervisor, peers, and customers.", 
				"Ability to work independently.",
				"Ability to work cooperatively with supervision or as part of a team.",
				"Willingness to take on additional responsibilities.",
				"Reliability (attendance, punctuality, meeting deadlines)",
				"Adeptness at analyzing facts, problem solving, decision-making, and demonstrating good judgment.",
				"Helps employees to see the potential for developing their skills; assists them in eliminating barriers to their development.",
				"Takes timely and appropriate corrective/disciplinary action with employees. ",
				"Takes specific steps to create and develop their diverse workforce and to promote an inclusive environment."));
		
		ArrayList<String> performance = new ArrayList<>(Arrays.asList("Skill and proficiency in carrying out assignments.",
				"Possesses skills and knowledge to perform the job competently.",
				"Skill at planning, organizing and prioritizing workload.(For self and direct reports, if applicable)",
				"Holds self accountable for assigned responsibilities; sees tasks through to completion in a timely manner.",
				"Proficiency at improving work methods and procedures as a means toward greater efficiency.",
				"Identifies performance expectations, gives timely feedback and conducts formal performance appraisals.",
				"Delegates responsibility where appropriate, based on the employee’s ability and potential."));
		this.overall = new ArrayList<String>(performance);
		this.overall.addAll(behavioral);

	}
	
	public ArrayList<String> getPeerq(){
		return behavioral;
	}
	public ArrayList<String> getManagerq(){
		return overall;
	}
	

}
