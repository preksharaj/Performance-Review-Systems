package com.example.demoapp.springproject;

import java.util.ArrayList;
import java.util.List;

public class YearlyScores {
	private String year; 
	private List<Pair> quarterOne; 
	private List<Pair> quarterTwo; 
	private List<Pair> quarterThree; 
	private List<Pair> quarterFour; 
	
	public static void main(String[] args) {
		
	}

	public YearlyScores(String year) {
		this.year = year; 
		quarterOne = new ArrayList<Pair>();
		quarterTwo = new ArrayList<Pair>();
		quarterThree = new ArrayList<Pair>();
		quarterFour = new ArrayList<Pair>();
	}

	public List<Pair> getQuarterOne() {
		return quarterOne;
	}

	public void setQuarterOne(List<Pair> quarterOne) {
		this.quarterOne = quarterOne;
	}

	public List<Pair> getQuarterTwo() {
		return quarterTwo;
	}

	public void setQuarterTwo(List<Pair> quarterTwo) {
		this.quarterTwo = quarterTwo;
	}

	public List<Pair> getQuarterThree() {
		return quarterThree;
	}

	public void setQuarterThree(List<Pair> quarterThree) {
		this.quarterThree = quarterThree;
	}

	public List<Pair> getQuarterFour() {
		return quarterFour;
	}

	public void setQuarterFour(List<Pair> quarterFour) {
		this.quarterFour = quarterFour;
	}

}