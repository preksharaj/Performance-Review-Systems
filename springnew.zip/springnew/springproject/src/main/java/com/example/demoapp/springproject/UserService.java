package com.example.demoapp.springproject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.mongodb.Mongo;
import com.mongodb.MongoClient;

@Service
public class UserService {
	MongoOperations mongoOperation= new MongoTemplate(new MongoClient("localhost:27017"), "userdb");
	MongoOperations mongoOperation2= new MongoTemplate(new MongoClient("localhost:27017"), "userdb2");

//	ApplicationContext ctx =
//            new AnnotationConfigApplicationContext(SpringMongoConfig.class);
//	@Autowired
//	MongoOperations mongoOperation = (MongoOperations) ctx.getBean("mongoTemplate");
	


	public void addUser(User user) {
		mongoOperation.save(user);
		//mongoOperation2.save(user);
	}

	public List<User> getUser() {
		return this.mongoOperation.findAll(User.class);

	}
	public User getSingle(String username,String password) {
		Query q = new Query();
		q.addCriteria(Criteria.where("username").is(username).and("password").is(password));
		return mongoOperation.findOne(q, User.class);

	}
	
	
	}
