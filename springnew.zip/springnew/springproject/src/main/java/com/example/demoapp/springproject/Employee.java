package com.example.demoapp.springproject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "employee")
public class Employee {

	@Id
	private String id;
	private String empId; 
	private String title;
	private String fullName; 
	private String teamName; 
	private String[] teamMembers; 
	private String managerName; 
	private String[] managerPeers; 
	private LinkedHashMap<String, List<Pair>> peerScoreObject;
	/**
	 * Represents the total score given by all their peers 
	 */
	private int totalPeerScore; 
	/**
	 * Represents the score given by the employee's manager
	 */
	private int managerScore;
	/**
	 * Total score of an employee. Formula is totalscore = totalPeerScore(.20) + managerScore(.80)
	 */
	private int totalScore; 
	/**
	 * This is an overall score for a manager
	 */
	private int teamScore; 

	public Employee(String empId, String title, String fullName, String teamName, String[] teamMembers,
			String managerName, String[] managerPeers, int managerScore) {
		this.empId = empId;
		this.title = title;
		this.fullName = fullName;
		this.teamName = teamName;
		this.teamMembers = teamMembers;
		this.managerName = managerName;
		this.managerPeers = managerPeers;
		this.managerScore = managerScore;
	}
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getEmpId() {
		return empId;
	}
	
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getFullName() {
		return fullName;
	}
	
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	public String getTeamName() {
		return teamName;
	}
	
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String[] getTeamMembers() {
		return teamMembers;
	}
	
	public void setTeamMembers(String[] teamMembers) {
		this.teamMembers = teamMembers;
	}
	
	public String getManagerName() {
		return managerName;
	}
	
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	
	public String[] getManagerPeers() {
		return managerPeers;
	}
	
	public void setManagerPeers(String[] managerPeers) {
		this.managerPeers = managerPeers;
	}

	public LinkedHashMap<String, List<Pair>> getPeerScoreObject() {
		return peerScoreObject;
	}

	public void setPeerScoreObject(LinkedHashMap<String, List<Pair>> peerScoreObject) {
		this.peerScoreObject = peerScoreObject;
	}
	
	public int getPeerScore() {
		return totalPeerScore;
	}

	public void setPeerScore(int peerScore) {
		this.totalPeerScore = peerScore;
	}
	
	public int getManagerScore() {
		return managerScore;
	}
	
	public void setManagerScore(int managerScore) {
		this.managerScore = managerScore;
	} 
	
	public int getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	
	public int calculateTotalScore() {
		return this.getManagerScore()+this.getPeerScore();
	}

	public int getTeamScore() {
		return teamScore;
	}

	public void setTeamScore(int teamScore) {
		this.teamScore = teamScore;
	}
	
	
}
