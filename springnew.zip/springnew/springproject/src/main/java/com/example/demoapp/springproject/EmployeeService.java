package com.example.demoapp.springproject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.mongodb.MongoClient;

@Service
public class EmployeeService {
	MongoOperations mongoOperation= new MongoTemplate(new MongoClient("localhost:27017"), "employeedb");
	
	public void addEmployee(Employee e1) {
		initPeerScoreObject(e1);
		mongoOperation.save(e1);
	}
	
	public Employee findEmpByIdQuery(String empid) {
		Query q = new Query();
		q.addCriteria(Criteria.where("empId").is(empid));
		return mongoOperation.findOne(q, Employee.class);
	}

	public Employee findEmpByFullNameQuery(String fullName) {
		Query q = new Query();
		q.addCriteria(Criteria.where("fullName").is(fullName));
		return mongoOperation.findOne(q, Employee.class);
	}
	
	public List<Employee> findEmpByTeamNameQuery(String teamName) {
		Query q = new Query();
		q.addCriteria(Criteria.where("teamName").is(teamName));
		return mongoOperation.find(q, Employee.class);
	}

	public Map<String, String> getdashboard(String empid) {
		int totalscore=0;
		Query q = new Query();
		q.addCriteria(Criteria.where("empId").is(empid));
		Employee e3=mongoOperation.findOne(q, Employee.class);
		int mscore=e3.getManagerScore();
		int pscore=0;
		int count=0;
		List<Pair> p=e3.getPeerScoreObject().get("Q4");
		for(Pair p3 : p) {
			if(p3.getScore()!=0) {
				pscore+=p3.getScore();
				count++;
			}
		}
		pscore=pscore/count;
		totalscore=pscore+mscore;
		Map<String,String> resultscore=new HashMap<String,String>();
		resultscore.put("fullname", e3.getFullName());
		resultscore.put("title", e3.getTitle());
		resultscore.put("teamname", e3.getTeamName());
		resultscore.put("managername", e3.getManagerName());
		resultscore.put("mscore", Integer.toString(mscore));
		resultscore.put("pscore", Integer.toString(pscore));
		resultscore.put("tscore", Integer.toString(totalscore));
		return resultscore;
	}
	
	public String getTitle(String empid) {
		return findEmpByIdQuery(empid).getTitle();
	}
	
	public String getFullName(String empid) {
		return findEmpByIdQuery(empid).getFullName();
	}
	
	public String getTeamName(String empid) {
		return findEmpByIdQuery(empid).getTeamName();
	}
	
	public String[] getTeamMembers(String empid) {
		return findEmpByIdQuery(empid).getTeamMembers();
	}
	
	public String getManagerName(String empid) {
		return findEmpByIdQuery(empid).getManagerName();
	}
	
	public String[] getManagerPeers(String empid) {
		return findEmpByIdQuery(empid).getManagerPeers();
	}

	public LinkedHashMap<String, List<Pair>> getPeerScoreObject(String empid) {
		return findEmpByIdQuery(empid).getPeerScoreObject();
	}
	
	public void initPeerScoreObject(Employee e1) {
		LinkedHashMap<String, List<Pair>> peerScoreObject = e1.getPeerScoreObject();
		// If the PeerScoreObject does not exist, create the object and initalize the quarters (Q1-Q4) with empty lists 
		if(e1.getPeerScoreObject() == null) {
			System.out.println("isnull");
			peerScoreObject = new LinkedHashMap<String, List<Pair>>();
			// Initialize empty lists of Pair for each quarter
			peerScoreObject.put("Q1", new ArrayList<Pair>());
			peerScoreObject.put("Q2", new ArrayList<Pair>());
			peerScoreObject.put("Q3", new ArrayList<Pair>());
			peerScoreObject.put("Q4", new ArrayList<Pair>());
		}
		e1.setPeerScoreObject(peerScoreObject);	
		mongoOperation.save(e1);
	}
	
	/**
	 * @param empid The person who reviewed you
	 * @param fullName The person you are reviewing
	 * @param peerScore The score that the person reviewed you gave you
	 * @param quarter The quarter which the review corresponds to (Q1-Q4)
	 * @return
	 */
	public String setPeerScoreObject(String empid, String fullName, int peerScore, String quarter) {
		// Employee object of person you are reviewing 
		Employee e1 = findEmpByFullNameQuery(fullName);
		LinkedHashMap<String, List<Pair>> peerScoreObject;
		List<Pair> tempList; 
		peerScoreObject = e1.getPeerScoreObject(); 
		tempList = peerScoreObject.get(quarter);
		tempList.add(new Pair(empid, peerScore));
		peerScoreObject.put(quarter, tempList);
		e1.setPeerScoreObject(peerScoreObject);	
		updateTotalPeerScore(e1, quarter);
		mongoOperation.save(e1);
		return "done";
	}

	public int getPeerScore(String empid) {
		return findEmpByIdQuery(empid).getPeerScore(); 
	}

	/**
	 * This method is automatically called from setPeerScoreObject() to update the peerScore variable tied to each Employee model 
	 * @param e1
	 * @param peerScoreObject
	 * @param quarter
	 * @return
	 */
	public void updateTotalPeerScore(Employee e1, String quarter) {
		int currentQuarterPeerScore = 0;
		List<Pair> tempList = e1.getPeerScoreObject().get(quarter); 
		for(Pair p : tempList) {
			currentQuarterPeerScore += p.getScore(); 
		}
		// find the average = total score / # of reviews for that quarter 
		currentQuarterPeerScore = currentQuarterPeerScore/tempList.size();
		System.out.println("score: "+currentQuarterPeerScore);
		e1.setPeerScore(currentQuarterPeerScore);
		mongoOperation.save(e1);
	}

	public int getManagerScore(String empid) {
		return findEmpByIdQuery(empid).getManagerScore();
	}
	
	public String setManagerScore(String fullName, int managerScore) {
		Employee e1= findEmpByFullNameQuery(fullName);
		e1.setManagerScore(managerScore);
		mongoOperation.save(e1);
		return "score stored in db";
	}
	
	public List<HashMap<String,String>> getTeamData(String teamName){
		List<Employee> emplist = findEmpByTeamNameQuery(teamName);
		List<HashMap<String,String>> newemplist=new ArrayList<HashMap<String,String>>();
		int teamscore=0;
		for(Employee e:emplist) {
			int pscore=0;
			int count=0;
			int totalscore=0;
			Map<String,String> m =new HashMap<String,String>();
			List<Pair> p=e.getPeerScoreObject().get("Q4");
			for(Pair p3:p) {
				if(p3.getScore()!=0) {
					pscore+=p3.getScore();
					count++;
				}
			}
			pscore=pscore/count;
			totalscore=pscore+e.getManagerScore();
			m.put("fullname", e.getFullName());
			m.put("mscore",  Integer.toString(e.getManagerScore()));
			m.put("pscore",  Integer.toString(pscore));
			m.put("tscore",  Integer.toString(totalscore));
			System.out.println(m);
			teamscore+=totalscore;
			newemplist.add((HashMap<String, String>) m);
		}
		return newemplist; 
	}
	
	
}