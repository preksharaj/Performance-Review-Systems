package com.example.demoapp.springproject;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService service;
	
	
	@RequestMapping(value="/logincreate", method = RequestMethod.POST)
	public void addUser(@RequestParam(value="username",required=true) String username , @RequestParam(value="password",required=true)String password,@RequestParam(value="empId",required=true)String empId,@RequestParam(value="title",required=true)String title){ //Take that JSON body and convert it to a Product instance and pass it into this method
		User user=new User(username,password,empId,title);
		 service.addUser(user);
	}
	
	@RequestMapping(value="/users", method = RequestMethod.GET)
	public List<User> getUser() {
		 return service.getUser();
	}
	@RequestMapping(value="/login", method = RequestMethod.GET)
	public List<String> getSingle(@RequestParam(value="username",required=true) String username,@RequestParam(value="password",required=true)String password){ //Take that JSON body and convert it to a Product instance and pass it into this method
		 User u=service.getSingle(username,password);
		 List<String> login= new ArrayList<String>();
		 login.add(u.getUsername());
		 login.add(u.getPassword());
		 login.add(u.getempId());
		 login.add(u.gettitle());
		 return login;
	}
	

}
