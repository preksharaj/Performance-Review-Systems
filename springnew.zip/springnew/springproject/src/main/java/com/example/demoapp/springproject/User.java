package com.example.demoapp.springproject;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "users")
public class User {

	@Id
	private String id;

	private String username;

	private String password;
	
	private String empId;
	private String title;
	
	public User() {
	}
	
	public User(String username,String password,String empId,String title) {
		this.username=username;
		this.password=password;
		this.empId=empId;
		this.title=title;
	}

	public String gettitle() {
		return title;
	}

	public void settitle(String title) {
		this.title = title;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	public String getempId() {
		return empId;
	}

	public void setempId(String empId) {
		this.empId = empId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	//getter, setter, toString, Constructors

}
