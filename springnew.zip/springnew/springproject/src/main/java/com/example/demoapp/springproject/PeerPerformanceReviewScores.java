package com.example.demoapp.springproject;

import java.util.ArrayList;
import java.util.List;

public class PeerPerformanceReviewScores {
	List<YearlyScores> listOfYearlyScores; 
	
	
	public PeerPerformanceReviewScores() {
		this.listOfYearlyScores = new ArrayList<YearlyScores>();
	}
	
	public void addNewYear(String year) {
		listOfYearlyScores.add(new YearlyScores(year));
	}
}
