package com.example.demoapp.springproject;

public class Pair {
	private String empid; 
	private int score; 
	
	public Pair(String empid, int score) {
		this.empid = empid; 
		this.score = score; 
	}

	public String getEmpid() {
		return empid;
	}

	public void setEmpid(String empid) {
		this.empid = empid;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
}
