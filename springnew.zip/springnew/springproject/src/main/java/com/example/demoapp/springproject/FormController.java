package com.example.demoapp.springproject;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/review")
public class FormController {
	@Autowired
	private FormService fservice;

	@RequestMapping(value="/peer", method = RequestMethod.GET)
	public ArrayList<String> getPeerq(){ //Take that JSON body and convert it to a Product instance and pass it into this method
		 return fservice.getPeerq();
		 
	}
	@RequestMapping(value="/manager", method = RequestMethod.GET)
	public ArrayList<String> getManagerq(){ //Take that JSON body and convert it to a Product instance and pass it into this method
		 return fservice.getManagerq();
		 
	}
	

}
