package com.example.demoapp.springproject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;

	@RequestMapping(value="/add", method = RequestMethod.POST)
	public void addUser(@RequestParam(value="empid",required=true) String empid, 
			@RequestParam(value="title",required=true) String title,
			@RequestParam(value="fullname",required=true) String fullName, 
			@RequestParam(value="teamname",required=true) String teamName, 
			@RequestParam(value="teammembers",required=true) String[] teamMembers, 
			@RequestParam(value="managername",required=true) String managerName, 
			@RequestParam(value="managerpeers",required=true, defaultValue="null") String[] managerPeers, 
			@RequestParam(value="managerscore",required=true) int managerScore) { 
		Employee e1 = new Employee(empid, title, fullName, teamName, teamMembers, managerName, managerPeers, managerScore);
		employeeService.addEmployee(e1);
	}	
	
	@RequestMapping(value="/getdashboard", method = RequestMethod.GET)
	public Map<String,String> getdashboard(@RequestParam(value="empid",required=true) String empid){ 
		return employeeService.getdashboard(empid);
	} 
	
	@RequestMapping(value="/gettitle", method = RequestMethod.GET)
	public String getTitle(@RequestParam(value="empid",required=true) String empid){ 
		String test = employeeService.getTitle(empid);
		System.out.println(test);
		return test;
	}
	
	@RequestMapping(value="/getfullname", method = RequestMethod.GET)
	public String getFullName(@RequestParam(value="empid",required=true) String empid) { 
		return employeeService.getFullName(empid);
	}
	
	@RequestMapping(value="/getteamname", method = RequestMethod.GET)
	public String getTeamName(@RequestParam(value="empid",required=true) String empid) { 
		return employeeService.getTeamName(empid);
	}
	
	@RequestMapping(value="/getteammembers", method = RequestMethod.GET)
	public String[] getTeamMembers(@RequestParam(value="empid",required=true) String empid) {
		return employeeService.getTeamMembers(empid);
	}
	
	@RequestMapping(value="/getmanagername", method = RequestMethod.GET)
	public String getManagerName(@RequestParam(value="empid",required=true) String empid) {
		return employeeService.getManagerName(empid);
	}

	@RequestMapping(value="/getmanagerpeers", method = RequestMethod.GET)
	public String[] getManagerPeers(@RequestParam(value="empid",required=true) String empid){ 
		return employeeService.getManagerPeers(empid);
	}
	
	@RequestMapping(value="/getpeerscoreobject", method = RequestMethod.GET)
	public LinkedHashMap<String, List<Pair>> getPeerScoreObject(@RequestParam(value="empid",required=true) String empid){
		return employeeService.getPeerScoreObject(empid);
	}

	@RequestMapping(value="/setpeerscoreobject", method = RequestMethod.POST)
	public String setPeerScoreObject(@RequestParam(value="empid",required=true) String empid, @RequestParam(value="fullname",required=true) String fullName, 
			@RequestParam(value="peerscore",required=true) int peerScore, @RequestParam(value="quarter",required=true) String quarter) {
		return employeeService.setPeerScoreObject(empid, fullName, peerScore, quarter);
	}
	
	@RequestMapping(value="/getpeerscore", method = RequestMethod.GET)
	public int getPeerScore(@RequestParam(value="empid",required=true) String empid){
		return employeeService.getPeerScore(empid);
	}

	@RequestMapping(value="/getmanagerscore", method = RequestMethod.GET)
	public int getManagerScore(@RequestParam(value="empid",required=true) String empid){ 
		return employeeService.getManagerScore(empid);
	}
	
	@RequestMapping(value="/setmanagerscore", method = RequestMethod.POST)
	public String getManagerScore(@RequestParam(value="fullname",required=true) String fullName, @RequestParam(value="managerScore",required=true)int managerScore){ 
		return employeeService.setManagerScore(fullName,managerScore);
	}

	@RequestMapping(value="/getteamdata", method = RequestMethod.GET)
	public List<HashMap<String,String>> getOneTeamMembers(@RequestParam(value="teamname",required=true) String teamname){ 
		return employeeService.getTeamData(teamname);
	} 
}
